export const appColor = {
    linkColor: 'text-sky-900',
    baseTextColor: 'text-black',
    baseTextPara1Color: 'text-neutral-500 ',
    baseBgColor:'bg-[#FFFDF2]'
}
export const style = {
    paragraph: ' font-semibold   text-neutral-800 '
}