

export function getHeaderConfig(token){
    return { Authorization:token}
}