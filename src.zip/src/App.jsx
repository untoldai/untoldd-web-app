import React from 'react'


import KidsWareHomepage from './pages/kidsware/KidsWareHomepage'
const App = () => {
  return (
    <KidsWareHomepage />
  )
}

export default App