export const categorySection = [
   
    {
        id:1,
        imgUrl:'https://th.bing.com/th/id/OIP.g2sDp0LPQfKg6B4sBubGUwHaHa?rs=1&pid=ImgDetMain',
        title:"Girls"
    },
    {
        id:2,
        imgUrl:'https://th.bing.com/th/id/OIP.hWg4HabvCiCKhbWWcg4YqwAAAA?rs=1&pid=ImgDetMain',
        title:"Kids Zone"
    },

    {
        id:4,
        imgUrl:'https://th.bing.com/th/id/OIP.MehnjMBUkxjm_abf6puCoAAAAA?rs=1&pid=ImgDetMain',
        title:"Boy "
    },
]