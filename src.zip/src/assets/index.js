import LogoFinal from './LogoFInal.jpeg'
import UntloddLogo from "./UntolddLogo.png"
import SphereObject from "./icon/sc.png";
import ExploreImage from './ExploreStore.png';
import PartnerButton from "./Partner.png";
import UntolddBanner from "./untolddbanner1.png";
import Perfume from "./products/perfume.png";
import BlackPerfume from "./products/blackperfume.png";
import Cloth1 from "./products/Cloth1.png";
import Cloth2 from "./products/Cloth2.png";
import Avatar from "./Avatar.png";
import Icon1 from "./icon/influnecer.png";
import Icon2 from "./icon/infulencer2.png";
import TwitterICon from "./icon/twitter-icon.png";
import InstagramIcon from "./icon/instagram-icon.png";
import LinkedinIcon from "./icon/linkedin-icon.png";
import BeautySlider1 from "./products/beautySlider1.png";
import BeautySlider2 from "./products/beautySlider2.png";
import BeautySlider3 from "./products/beautySlider3.webp";
import BeautySlider4 from "./products/beautySlider4.webp";
import Product23 from "./products/product23.jpg"
import BeautySlider5 from "./products/beautySlider5.jpg";
import BeautyBanner1 from "./beautybanner1.png";
import Icon12 from "./icon1.jfif";
import CreamBox from "./creamBox.png";
import Beluga from "./beluga.png";
import BelugaChild from "./belugachild.png";
import BelugaTshirt from "./belugatshirt.png";
import Contactus from "./contactus.png";
import SimplicBanner from "./SimplicBanner.jpeg"
import Banner2 from "./Banner2.jpg";
import Banner3 from "./Banner3.jpg";
import Banner4 from "./Banner4.jpg";
export {
    UntloddLogo,
    SphereObject,
    ExploreImage,
    PartnerButton,
    UntolddBanner,
    Perfume,
    BlackPerfume,
    Cloth1,
    Cloth2,
    Avatar,
    Icon1,
    Icon2,
    TwitterICon,
    InstagramIcon,
    LinkedinIcon,
    BeautySlider1,
    BeautySlider2,
    BeautySlider3,
    Product23,
    BeautySlider4,
    BeautySlider5,
    BeautyBanner1,
    Icon12,
    CreamBox,
    Beluga,
    BelugaChild,
    BelugaTshirt,
    Contactus,
    SimplicBanner,
    LogoFinal,
    Banner2,
    Banner3,
    Banner4
}